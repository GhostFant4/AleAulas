﻿// See https://aka.ms/new-console-template for more information
using System.Diagnostics.Tracing;

DiasDaSemana dia = DiasDaSemana.Quarta;

switch (dia)
{
    case DiasDaSemana.Segunda:
        Console.WriteLine("Hoje é Segunda");
        break;
    case DiasDaSemana.Terca:
        Console.WriteLine("Hoje é Terça");
        break;
    case DiasDaSemana.Quarta:
        Console.WriteLine("Hoje é Quarta");
        break;
    case DiasDaSemana.Quinta:
        Console.WriteLine("Hoje é Segunda");
        break;
    case DiasDaSemana.Sexta:
        Console.WriteLine("Hoje é Terça");
        break;
    case DiasDaSemana.Sabado:
        Console.WriteLine("Hoje é Quarta");
        break;
    case DiasDaSemana.Domingo:
        Console.WriteLine("Hoje é Segunda");
        break;
}

enum DiasDaSemana { Segunda, Terca, Quarta, Quinta, Sexta, Sabado, Domingo}
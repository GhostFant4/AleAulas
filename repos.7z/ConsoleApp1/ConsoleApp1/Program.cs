﻿int num1 = 1;
int num2 = 2;
if (num1 == num2)
{
    Console.WriteLine("Sexo bixo kkkkkk");
}

else
{
    Console.WriteLine("Sem sexo");
}

bool condicao = true;



/*while (condicao) 
{
    Console.WriteLine("Repetindo até ser falso");
    condicao = true;
}
*/

do 
{
    Console.WriteLine("Repetindo até ser falso");
    num1 =+ 1;
} while (num1 == 2);


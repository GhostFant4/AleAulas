﻿// See https://aka.ms/new-console-template for more information
//Console.WriteLine("Hello, World!");
Meses mesat = Meses.Fev;
//Console.WriteLine((int)mesat);

bool condicao = false;

if ((int)mesat == 10)
{
    Console.WriteLine(mesat);
}


else
{
    Console.WriteLine((int)mesat);
}
enum Meses { Jam, Fev = 10, mar, abr, maio }
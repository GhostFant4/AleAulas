﻿List<string> nomes = new List<string>();
string nome;
List<float> valor = new List<float>();
List<int> quanti = new List<int>();
int quant;
int nu =0;
float val = 0;
bool on = true;
bool on2 = true;

while (on)
{

    on2 = true;
    Console.WriteLine("Qual o nome do produto?");
    nome = Console.ReadLine();
    nomes.Add(nome);

    Console.Write($"valor do produto {nome} R$:");
    while (!float.TryParse(Console.ReadLine(), out val))
    {
        Console.WriteLine("Valor invalido digite um valor valido");
    }
    valor.Add(val);

    Console.Write($"A quantidade do produto {nome}:");
    while (!int.TryParse(Console.ReadLine(), out quant))
    {
        Console.WriteLine("Valor invalido digite um valor valido");
    }
    quanti.Add(quant);

    while (on2) {
        Console.WriteLine($"O que deseja fazer? \n1)Consultar \n2)Adicionar \n3)Fechar");
        while (!int.TryParse(Console.ReadLine(), out nu))
        {
            Console.WriteLine("Valor invalido digite um valor valido");
        }
        if (nu == 1)
        {
            for (int i = 0; i < quanti.Count; i++)
            {
                Console.WriteLine($"Produto:{nomes[i]} \nPreço R$:{valor[i]} \nQuantidade:{quanti[i]} \nValor em estoque:{valor[i] * quanti[i]}\n");

            }
        }

        else if (nu == 3)
        {
            Console.WriteLine("Fechando programa");
            on2 = false;
            on = false;
        }
        else if (nu == 2)
        {
            on2 = false;
        }

    }
    
}

﻿List<float> Compras = new List<float>();
float valor = 0;
double total = 0;
double desconto = 0;
bool compras = true;
while (compras)
{
    Console.Write("insira o valor do produto R$: ");
    while (!float.TryParse(Console.ReadLine(), out valor))
    {
        Console.WriteLine("Valor invalido, tente um valor valido");
    }
    if (valor < 0)
    {
        Console.WriteLine($"Tá se achando muito espertinho, vê se eu não te dou uma coça pra deixar de ser besta"); //pequeno eaters egg pra desestressar a prova (por favor n tira ponto por conta disso 🙏😔)
    }

    else if (valor != 0 || valor>0)
    {
        Compras.Add(valor);
        Console.WriteLine($"Você estará pagando por esses itens:");
        foreach (var item in Compras)
        {
            Console.WriteLine($"R${item}");
        }

     total += valor;

    }

    else
    {
        break;
    }
    Console.WriteLine("Se você acabou suas compras insira o valo 0 para ir ao pagamento");
}



if (total >= 100)
{
    desconto = total*0.10;
    Console.WriteLine($"O cupom de 10% foi aplicado, o valor final da compra seria de R${total}, mas com o desconto é de R${total-desconto}, o desconto foi de R${desconto}");
}

else
{
Console.WriteLine($"Você pagara R${total}");
}

Console.WriteLine("Eseses foram os valores dos produtos gastos");
foreach (var item in Compras)
{
    Console.WriteLine($"R${item}");
}
﻿int alunos = 0;
Console.WriteLine("Qual a quantidade de alunso?");
while (!int.TryParse(Console.ReadLine(), out alunos))
{
    Console.WriteLine("Valor invalido, tente um valor valido");
}
string nome;
string[] nomes = new string[alunos];
float[] notas = new float[alunos];

for (int i = 0; i < nomes.Length; i++)
{
    Console.WriteLine("Qual o nome do aluno?");
        nome = Console.ReadLine();
        nomes[i] =nome;

        Console.Write($"A nota do aluno {nome} é:");
        while (!float.TryParse(Console.ReadLine(), out notas[i]))
    {
        Console.WriteLine("Valor invalido digite um valor valido");
    }

    
}

for  (int i = 0;i < nomes.Length; i++)
{
    if (notas[i] < 5)
        Console.WriteLine($"{nomes[i]} é Conceito: D");

    else if (notas[i] < 7)
    {
        Console.WriteLine($"{nomes[i]} é Conceito: C");
    }

    else if (notas[i] < 9)
    {
        Console.WriteLine($"{nomes[i]} é Conceito: B");
    }
    else if (notas[i] <= 10)
    {
        Console.WriteLine($"{nomes[i]} é Conceito: A");
    }

    else
    {
        Console.WriteLine($"A nota do aluno {nomes[i]} é incompativel com o sistema");
    }

}
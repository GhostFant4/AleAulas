﻿float[] dias = new float[5];
float media = 0;
float maior = 0;
float menor = 0;

for (int i = 0; i < dias.Length; i++)

{
    Console.WriteLine($"Escreva a temperatura do {i+1}º dia");
    while (!float.TryParse(Console.ReadLine(), out dias[i]))
    {
        Console.WriteLine("erro");
    }

    media += dias[i];
}

for (int i =0 ; i < dias.Length; i++)
{
    for (int j = 0 ;j < dias.Length ; j++)

    if (dias[j] > dias[i])
    {
        maior = dias[j];
    }
    
}

for (int i = 0; i < dias.Length; i++)
{
    for (int j = 0; j < dias.Length; j++)

        if (dias[j] < dias[i])
        {
            menor = dias[j];
        }

}

Console.WriteLine($"A temperatua media da semana foi: {media/5}Cº");
Console.WriteLine($"A temperatura mais quente foi de {maior}Cº");
Console.WriteLine($"A temperatura mais fria foi de {menor}Cº");

